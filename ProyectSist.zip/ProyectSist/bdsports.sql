-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 21-05-2023 a las 01:38:03
-- Versión del servidor: 10.4.28-MariaDB
-- Versión de PHP: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `bdsports`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `clientes`
--

CREATE TABLE `clientes` (
  `id` int(11) NOT NULL,
  `nombres` varchar(80) NOT NULL,
  `apellidos` varchar(80) NOT NULL,
  `email` varchar(50) NOT NULL,
  `telefono` varchar(20) NOT NULL,
  `estatus` tinyint(4) NOT NULL,
  `fecha_alta` datetime NOT NULL,
  `fecha_modifica` datetime DEFAULT NULL,
  `fecha_baja` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `clientes`
--

INSERT INTO `clientes` (`id`, `nombres`, `apellidos`, `email`, `telefono`, `estatus`, `fecha_alta`, `fecha_modifica`, `fecha_baja`) VALUES
(1, 'Ruben', 'Gutierrez', 'gutierrezruben.000@gmail.com', '6391508697', 1, '2023-05-04 12:08:46', NULL, NULL),
(2, 'tipo', 'prueba', 'soportesso04@gmail.com', '6391508697', 1, '2023-05-18 00:17:59', NULL, NULL);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `compra`
--

CREATE TABLE `compra` (
  `id` int(11) NOT NULL,
  `id_transaccion` varchar(20) NOT NULL,
  `fecha` datetime NOT NULL,
  `status` varchar(20) NOT NULL,
  `email` varchar(50) NOT NULL,
  `id_cliente` varchar(20) NOT NULL,
  `total` decimal(10,2) NOT NULL,
  `medio_pago` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `detalle_compra`
--

CREATE TABLE `detalle_compra` (
  `id` int(11) NOT NULL,
  `id_compra` int(11) NOT NULL,
  `id_producto` int(11) NOT NULL,
  `nombre` varchar(200) NOT NULL,
  `precio` decimal(10,2) NOT NULL,
  `cantidad` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `productos`
--

CREATE TABLE `productos` (
  `id` int(11) NOT NULL,
  `nombre` varchar(200) NOT NULL,
  `descripcion` text NOT NULL,
  `precio` decimal(10,2) NOT NULL,
  `descuento` tinyint(4) NOT NULL DEFAULT 0,
  `id_categoria` int(11) NOT NULL,
  `activo` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `productos`
--

INSERT INTO `productos` (`id`, `nombre`, `descripcion`, `precio`, `descuento`, `id_categoria`, `activo`) VALUES
(1, 'Playera Deportivo Guadalajara', '<p>Camiseta edición jugador de la 1ª equipación del Deportivo Guadalajara 22/23 para los partidos de La LigaMX.\r\n\r\n- Tejido de gran elasticidad y secado rápido\r\n- 100% poliéster\r\n</p>\r\n<br>\r\n<b>Características:</b><br>\r\nMarca: Puma<br>\r\nColección: Temporada 22-23<br>\r\nModelo: 273-29<br>\r\nColor: Color: Azul y Roja. <br>', 600.00, 0, 1, 1),
(2, 'Playera Club America', '<p>Camiseta edición jugador de la 1ª equipación del Club America 22/23 para los partidos de La LigaMX.\r\n- Tecnología Nike Dri-FIT ADV\r\n- Tejido de gran elasticidad y secado rápido\r\n- 100% poliéster\r\n</p>\r\n<br>\r\n<b>Características:</b><br>\r\nMarca: Nike<br>\r\nColección: Temporada 22-23<br>\r\nModelo: 273-29<br>\r\nColor: Color: Azul. <br>', 700.00, 0, 1, 1),
(3, 'Playera Club Cruz Azul', '<p>Camiseta edición jugador de la 1ª equipación del Club Cruz Azul 22/23 para los partidos de La LigaMX.\r\n\r\n- Tejido de gran elasticidad y secado rápido\r\n- 100% poliéster\r\n</p>\r\n<br>\r\n<b>Características:</b><br>\r\nMarca: Joma<br>\r\nColección: Temporada 22-23<br>\r\nModelo: 273-29<br>\r\nColor: Color: Azul. <br>', 700.00, 0, 1, 1),
(4, 'Playera del FC Barcelona \"Edicion Moto Mami\"', '<p>Camiseta edición jugador de la 1ª equipación del FC Barcelona 22/23 para los partidos de La Liga.\r\n- Edicion Especial\r\n- Parche de La Liga en la manga derecha.\r\n- Tecnología Nike Dri-FIT ADV\r\n- Tejido de gran elasticidad y secado rápido\r\n- 100% poliéster\r\n</p>\r\n<br>\r\n<b>Características:</b><br>\r\nMarca: Addidas<br>\r\nColección: Temporada 22-23<br>\r\nModelo: 273-29<br>\r\nColor: Color: Azulgrana. <br>\r\n', 1500.00, 10, 1, 1),
(5, 'Playera del FC Real Madrid', '<p>Camiseta edición jugador de la 1ª equipación del FC Real Madrid 22/23 para los partidos de La Liga.\r\n- Parche de La Liga en la manga derecha.\r\n- Tecnología Addidas Dri-FIT ADV\r\n- Tejido de gran elasticidad y secado rápido\r\n- 100% poliéster\r\n</p>\r\n<br>\r\n<b>Características:</b><br>\r\nMarca: Addidas<br>\r\nColección: Temporada 22-23<br>\r\nModelo: 273-29<br>\r\nColor: Color: Blanca. <br>', 800.00, 0, 1, 1),
(6, 'Playera Manchester City', '<p>Camiseta edición jugador de la 1ª equipación del FC Manchester City 22/23 para los partidos de La Premier.\r\n- Tecnología Puma Dri-FIT ADV\r\n- Tejido de gran elasticidad y secado rápido\r\n- 100% poliéster\r\n</p>\r\n<br>\r\n<b>Características:</b><br>\r\nMarca: Puma<br>\r\nColección: Temporada 22-23<br>\r\nModelo: 273-29<br>\r\nColor: Color: Azul Cielo. <br>', 800.00, 0, 1, 1),
(7, 'Playera del Chelsea', '<p>Camiseta edición jugador de la 1ª equipación del Chelsea 22/23 para los partidos de La Premier.\r\n\r\n- Tecnología Nike Dri-FIT ADV\r\n- Tejido de gran elasticidad y secado rápido\r\n- 100% poliéster\r\n</p>\r\n<br>\r\n<b>Características:</b><br>\r\nMarca: Nike<br>\r\nColección: Temporada 22-23<br>\r\nModelo: 273-29<br>\r\nColor: Color: Blanca. <br>', 800.00, 0, 1, 1),
(8, 'Playera Inter de Milan', '<p>Camiseta edición jugador de la 1ª equipación del Inter de Milan 22/23 para los partidos de La Serie A.\r\n\r\n- Tecnología Nike Dri-FIT ADV\r\n- Tejido de gran elasticidad y secado rápido\r\n- 100% poliéster\r\n</p>\r\n<br>\r\n<b>Características:</b><br>\r\nMarca: Nike<br>\r\nColección: Temporada 22-23<br>\r\nModelo: 273-29<br>\r\nColor: Color: Azul. <br>', 800.00, 0, 1, 1),
(9, 'Playera del Napoli', '<p>Camiseta edición jugador de la 1ª equipación del Napoli 22/23 para los partidos de La Serie A.\r\n\r\n- Tejido de gran elasticidad y secado rápido\r\n- 100% poliéster\r\n</p>\r\n<br>\r\n<b>Características:</b><br>\r\nMarca: Armani<br>\r\nColección: Temporada 22-23<br>\r\nModelo: 273-29<br>\r\nColor: Color: Azul. <br>', 800.00, 0, 1, 1),
(10, 'Playera Edicion Mundial Qatar 22 \"Mexico\"', '<p>Camiseta edición jugador de la 1ª equipación de la Seleccion Mexicana Mundial de Qatar.\r\n\r\n- Tecnología Addidas Dri-FIT ADV\r\n- Tejido de gran elasticidad y secado rápido\r\n- 100% poliéster\r\n</p>\r\n<br>\r\n<b>Características:</b><br>\r\nMarca: Addidas<br>\r\nColección: Mundial Qatar<br>\r\nModelo: 273-29<br>\r\nColor: Color: Blanca, Decorado en Rojo. <br>', 1200.00, 0, 1, 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuarios`
--

CREATE TABLE `usuarios` (
  `id` int(11) NOT NULL,
  `usuario` varchar(30) NOT NULL,
  `password` varchar(120) NOT NULL,
  `activacion` int(11) NOT NULL DEFAULT 0,
  `token` varchar(40) NOT NULL,
  `token_password` varchar(40) DEFAULT NULL,
  `password_request` int(11) NOT NULL DEFAULT 0,
  `id_cliente` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `usuarios`
--

INSERT INTO `usuarios` (`id`, `usuario`, `password`, `activacion`, `token`, `token_password`, `password_request`, `id_cliente`) VALUES
(1, 'Ruben10', '$2y$10$Pi2gdSznjw2rqLnvR1HDQuK51kATZ4XG1C/47TSf4fHpHs5TXAipu', 1, '282be18289e309e4c76db2b8f91b1e0d', NULL, 0, 1),
(2, 'UsuarioPrueba', '$2y$10$Td7HbgqHwZQK8P39RSlRcuMFMCgQASv6P8ru9TKqX/DV85D0XUfeS', 1, '46ef283449c3d1030e98c0ba9195f0ea', NULL, 0, 2);

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `clientes`
--
ALTER TABLE `clientes`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `compra`
--
ALTER TABLE `compra`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `detalle_compra`
--
ALTER TABLE `detalle_compra`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `productos`
--
ALTER TABLE `productos`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_usuario` (`usuario`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `clientes`
--
ALTER TABLE `clientes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT de la tabla `compra`
--
ALTER TABLE `compra`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `detalle_compra`
--
ALTER TABLE `detalle_compra`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `productos`
--
ALTER TABLE `productos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
