<footer class="footer mt-auto py-2 bg-dark">
    <div class="container">
        <p class="text-center">
            <span class="text-white">&copy; <?php echo date('Y'); ?> <a href="https://github.com/RubenGtz0/ProyectSist">Sports Shop Online</a></span>
        </p>
    </div>
</footer>