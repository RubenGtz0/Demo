SimulacionVenta Datos 
Sandbx account
sb-f0fw4725345805@business.example.com
Cliente ID
AcHIxXDPERIZvU5eYT0CNJpsrfs7uHEJw_kO5FqXpiVUm6smLIXCnmGhYK8Bpnr-istwePd7iayGGSHq

1.-Para realizar una actualizacion fisica del sistema de pago paypal regresar al video 1 en la ultima parte se detalla este proceso.
2.-Meter la carpeta ProyectoSist en la carpeta htdocs de xampp, nombre de la pagina http://localhost/ProyectoSist/ .
3.-Instale plugins de php 
-php intelephense
-php extension pack
-php server 
Para poder ejecutar los programas php desde vsC necesitan ver el video :https://www.youtube.com/watch?v=W9cDh_sC2As&t=11s
solo instalar plugins de php los de mysql no son necesarios 
en la parte de la creacion de base de datos para no utilizar cada quien una base separada intenten usar esta direccion en 
lugar de localhost 
private $hoostname = "localhost"; //127.0.0.1 en lugar de localhost 

En la descripcion de los productos se puede usar tag html para modificar la vista del texto con efectos de parrafo o negritas etc.
